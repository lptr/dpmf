class PacmanThread extends Thread 
{
	Pacman p;
	Proto prot;
	public PacmanThread(String s,Pacman thePacman,Proto proto) {
		super(s);
		p=thePacman;
		prot=proto;
		}

	public void run()
	{
		while (prot.theGame_Menu.theScore_Field.Get_lives()>0)
		{
			p.Start();
			p.Set_directions(p.nextmove,prot);
			p.Check_Bonus(p,prot);
			if (p.vanbomb)
			{
				p.Put_Bomb(prot,prot.Get_Time());
				p.vanbomb=false;
			}
			try
			{
			sleep (p.Speed*100);
			}
		catch (InterruptedException e){	}
		}
	}
}
