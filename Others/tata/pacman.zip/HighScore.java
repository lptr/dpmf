import java.io.*;
public class HighScore
{
	public String line;
	public String ered;
	int s=0;
	int t=0;
	int h=0;
	int g=0;
    char chars[] = new char [16];
	char seged[] = new char [16];
	char seged2[] = new char [16];
	public String nevek[]= new String[10];
	public int eredmeny[]= new int[10];
	Proto prot;
	public HighScore(Proto p)
	{
		prot=p;
	}
	public void ShowHighScore() {
//	prot.vi.highscore.setEditable(false);
		for (int n=0;n<10 ;n++ )
		{
	//		prot.vi.highscore.append(nevek[n]+eredmeny[n]+"\n");
		}
	}
/*	public void CheckHigh(int score)
	{
		if (score>eredmeny[9])
		{
			EnterHighScore(score);
		}
	}

	public void EnterHighScore(int score)
	{
		h=9;
			while (score>eredmeny[h])
			{
				s=h;
				h--;
			}
		while (t<9)
		{
			g=eredmeny[s];
			eredmeny[s]=score;
		}
	}*/

	public void LoadHighScore() {
		try
		{
		BufferedReader high=(new BufferedReader(new FileReader(new File("highscore.txt"))));
		for (int y=0;y<10 ;y++ )
			{
			s=0;
			line=high.readLine();
			chars = line.toCharArray();
			while (chars[s]!='#')
			{
				seged[s]=chars[s];
				s++;
			}
			s++;
			nevek[y]=new String(seged);
			s=17;
			t=0;
			while (chars[s]!='#')
			{
				seged2[t]=chars[s];
				t++;
				s++;
			}
			ered=String.valueOf(seged2,0,t);
			eredmeny[y]= Integer.parseInt(ered);
			}
			high.close();
		}
		catch (IOException e)
		{
		}
	}
public void SaveHighScore()
	{
		try
		{
		BufferedWriter high2=(new BufferedWriter(new FileWriter(new File("highscore.txt"))));	
		for (int y=0;y<10 ;y++ )
		{
		s=0;
					seged=nevek[y].toCharArray();
				high2.write(nevek[y]);
				high2.write('#');
				ered=String.valueOf(eredmeny[y]);
				high2.write(ered);
				high2.write('#');
				high2.write('\n');
			}
		high2.close();
		}
		catch (IOException e)
		{
		}
	}
}
