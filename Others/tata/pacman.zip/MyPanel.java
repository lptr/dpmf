import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class MyPanel extends JPanel
{
			
}
