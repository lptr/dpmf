import java.util.Random;

class MonsterThread extends Thread 
{
	int seged[]=new int[400];
	int ut[]=new int[400];
	Monster m;
	int dir;
	int u;
	int n=0;
	int actual=0;
	int irany;
	int szorny=0;
	int pacman=0;
	int legkisebb=0;
	int rendez[]=new int[4];
	Monster[] Monsters;
	Proto prot; 
	Random random=new Random();
	public MonsterThread(String s,Monster[] M,int number,Proto proto) {
		super(s);
		u=number;
		m=M[u];
		Monsters=M;
		prot=proto;
		for (int i=0;i<400 ;i++ )
		{
			seged[i]=0;
		}
		for (int i=0;i<4 ;i++ )
		{
			rendez[i]=0;
		}
		for (int i=0;i<400 ;i++ )
		{
			ut[i]=0;
		}
	}

	public void run()
	{
		while (true)
		{
			if (Monsters[u].Intelligent==false)
			{
			dir = random.nextInt(4);
			Monsters[u].Start();
			Monsters[u].Set_directions(dir,prot);
			}
			if (Monsters[u].Intelligent==true)
			{
			szorny=Monsters[u].GetX()*20+Monsters[u].GetY();
			seged[szorny]=1;
			pacman=prot.theGame_Menu.theGame.theLabyrinth.thePacman.GetX()*20+prot.theGame_Menu.theGame.theLabyrinth.thePacman.GetY();
			while ((seged[pacman])==0)
			{
					for (int g=0;g<400 ;g++ )
			{
				if (prot.theGame_Menu.theGame.theLabyrinth.Level_Map[g]==0)
				{
				if (seged[g+1]>0)
				{
					seged[g]=seged[g+1]+1;
				}
				if ((seged[g-1]>0)&&(g>0))
				{
					seged[g]=seged[g-1]+1;
				}
				if (seged[g+20]>0)
				{
					seged[g]=seged[g+20]+1;
				}
				if (seged[g-20]>0)
				{
					seged[g]=seged[g-20]+1;
				}
			}
			}
				}
				for (int y=0;y<400 ;y++ )
				{
					if (seged[y]==0)
					{
						seged[y]=1000;
					}
				}
			actual=pacman;
			while (ut[n]!=szorny)
			{
				rendez[0]=seged[actual+1];
				rendez[1]=seged[actual-1];
				rendez[2]=seged[actual+20];
				rendez[3]=seged[actual-20];
			for (int g=0;g<4 ;g++ )
			{
				for (int f=0;f<4 ;f++ )
				{
					if (rendez[g]<rendez[f])
					{
						legkisebb=rendez[g];
					}					
				}
			}	

		if (legkisebb==rendez[0])
	{
			ut[n]=actual+1;
	}				
	if (legkisebb==rendez[1])
	{
			ut[n]=actual-1;
	}				
	if (legkisebb==rendez[2])
	{
			ut[n]=actual+20;
	}				
	if (legkisebb==rendez[3])
	{
			ut[n]=actual-20;
	}				
	if (u==0)
	{
	System.out.println(ut[n]);
	}
				actual=ut[n];
				n++;
				}
			switch (ut[n-1]-szorny)
			{
			case -20: {irany=0;break;}
			case  20: {irany=2;break;}
			case  -1: {irany=3;break;}
			case  1: {irany=1;break;}
			
			}
			Monsters[u].Start();
			Monsters[u].Set_directions(irany,prot);
			}
			try
			{
			sleep (Monsters[u].Speed*200);
			}
		catch (InterruptedException e){	}
		}
	}
}
