#!/bin/sh
# $Id: makepacman.sh,v 1.2 2001/05/30 16:23:21 lptr Exp $
# $Date: 2001/05/30 16:23:21 $
# $Author: lptr $

SOURCEFILES="PacMan/*.java Util/Parser/ourParser.java ImageCache/ImageCache.java"
CLASSFILES="PacMan/*.class Util/Parser/*.class ImageCache/*.class"
DATAFILES="data/*.ttf data/aboutbox.html data/pacmanicon.gif"

rm PacMan.jar $CLASSFILES

javac -d . PacMan/*.java Util/Parser/ourParser.java ImageCache/ImageCache.java
jar cfm PacMan.jar PacMan.manifest $CLASSFILES $DATAFILES

rmdir -Rf Doc
mkdir Doc

javadoc -link http://java.sun.com/products/jdk/1.3/docs/api -use -private -locale hu_HU -encoding iso-8859-2 -charset iso-8859-2 -docencoding iso-8859-2 -d Doc -version -author -windowtitle "DPMF PacMan - v1.0" $SOURCEFILES
