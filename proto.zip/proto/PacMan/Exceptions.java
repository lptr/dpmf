// $Id: Exceptions.java,v 1.1 2001/04/27 13:09:00 lptr Exp $
// $Date: 2001/04/27 13:09:00 $
// $Author: lptr $

package PacMan;

class NextLevelException extends java.lang.Exception {
}

class LifeLostException extends java.lang.Exception {
}

class EndGameException extends java.lang.Exception {
}

